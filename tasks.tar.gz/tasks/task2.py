# return a list of all teams which contain the person
def exercise2(person, teams):
    return find_teams([], person, teams)

def find_teams(matching_teams, person, teams):
    for team in teams:
        if team.is_team:
            if person in team.members:
                matching_teams.append(team)
            else:
                t = find_teams([], person, team.members)
                if len(t) > 0:
                    matching_teams.append(team)
    return matching_teams

import data2
[print (t.displayname) for t in exercise2(data2.alice, data2.people)]
