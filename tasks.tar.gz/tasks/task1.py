# return a list of all teams which contain the person
def exercise1(person, teams):
    matching_teams = []
    for team in teams:
        if team.is_team and person in team.members:
            matching_teams.append(team)
    return matching_teams

import data1
[print (t.displayname) for t in exercise1(data1.alice, data1.people)]
